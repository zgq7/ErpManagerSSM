CREATE PROCEDURE customer_login(IN user VARCHAR(16), IN passwordz VARCHAR(16))
  BEGIN
DECLARE result TINYINT;
	#Routine body goes here...
	case when (SELECT count(*) from erp_customer where cardNo = user and password = passwordz) > 1
	then set result = 1;
	else set result = 0;
	end case;
	SELECT result;
END;

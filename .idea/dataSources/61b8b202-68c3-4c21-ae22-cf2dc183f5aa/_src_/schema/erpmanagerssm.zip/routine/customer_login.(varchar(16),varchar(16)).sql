CREATE PROCEDURE customer_login(IN user VARCHAR(16), IN passwordz VARCHAR(16))
  BEGIN
DECLARE result VARCHAR(5);
	case when 
	(SELECT count(*) as result from erp_customer where cardNo = user and password = passwordz ) > 1
	then set result = 'true' ;
	else set result = 'false' ;
	end case;
	select result;
END;
